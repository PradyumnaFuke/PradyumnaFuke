let spoil = document.getElementsByClassName("spoiler");

for (let i = 0; i < spoil.length; i++) {
  spoil[i].onclick = function () {
    if (this.classList.contains("spoiler")) {
      this.style.color = "--spoilerBGColor";
      this.style.backgroundColor = "--spoiled";
      this.classList.remove("spoiler");
      this.classList.add("spoiled");
    } else if (this.classList.contains("spoiled")) {
      this.style.color = "";
      this.style.backgroundColor = "";
      this.classList.remove("spoiled");
      this.classList.add("spoiler");
    }
  };
}

  tippy('.tooltip', {
    placement: 'top',
    allowHTML: true,
    maxWidth: 300,
    animation: 'shift-away',
    arrow: true,
    theme: 'my-tooltip',
  });
  
  //Scroll-button
document.getElementById("scrollTop").onclick = () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
};

document.getElementById("scrollBottom").onclick = () => {
  window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
};

//Toggle Scroll Button
const toggleBtn = document.getElementById('toggleScrollBtn');
const scrollBtn1 = document.getElementById('scrollTop');
const scrollBtn2 = document.getElementById('scrollBottom');

// Function to save visibility state to localStorage
function saveScrollButtonsState() {
  const state = {
    scrollTop: scrollBtn1.style.display,
    scrollBottom: scrollBtn2.style.display
  };
  localStorage.setItem('scrollButtonsState', JSON.stringify(state));
}

// Function to load visibility state from localStorage
function loadScrollButtonsState() {
  const savedState = localStorage.getItem('scrollButtonsState');
  if (savedState) {
    const state = JSON.parse(savedState);
    scrollBtn1.style.display = state.scrollTop || 'block';
    scrollBtn2.style.display = state.scrollBottom || 'block';
  }
}

// Initialize state on page load
window.addEventListener('DOMContentLoaded', loadScrollButtonsState);

// Toggle visibility and save state
toggleBtn.onclick = () => {
  [scrollBtn1, scrollBtn2].forEach(btn => {
    const isHidden = btn.style.display === 'none';
    btn.style.display = isHidden ? 'block' : 'none';
  });
  saveScrollButtonsState();
};



  const toggleNavBtn = document.getElementById('toggleNavBtn');
  const nav = document.getElementById('nav');

  // Load saved state from localStorage
  window.addEventListener('DOMContentLoaded', () => {
    const savedState = localStorage.getItem('navDisplay');
    if (savedState) {
      nav.style.display = savedState;
    }
  });

  // Toggle and save state
  toggleNavBtn.onclick = () => {
    const current = window.getComputedStyle(nav).display;
    const newState = current === 'none' ? 'inline-block' : 'none';
    nav.style.display = newState;
    localStorage.setItem('navDisplay', newState);
  };